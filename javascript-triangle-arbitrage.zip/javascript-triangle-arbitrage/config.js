var myaddress = "your wallet address"
var myprivatekey = "your privatekey to address"
var myseed = "your wallet seed" //only give this if your privatekey is stored in a wallet with accessibility example (hardwarewallets)
var networks = "1" //1 = ETH , 2 = BNB , 3 = Polygon 
var maxspend = "0.5" // max eth you want to spend. Note: Make sure you have that amount in the wallet you provided.
